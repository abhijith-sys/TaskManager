const PathConstants = {
    HOME: "/",
    TEAM: "/team",
    TEMPLATES:"templates",
    TEMPLATEADD:"/templateform"
}

export default PathConstants
