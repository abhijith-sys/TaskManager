import React from 'react';
import './App.css';
import MainRoute from './router/MainRoute';

function App() {
  return (
    <MainRoute/>
  );
}

export default App;
