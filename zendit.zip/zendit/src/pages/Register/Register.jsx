import React from 'react'

const Register = () => {
  return (
    <div>
      <h1>register</h1>
    </div>
  )
}

export default Register
